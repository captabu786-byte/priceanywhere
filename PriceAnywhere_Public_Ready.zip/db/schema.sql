create extension if not exists pgcrypto;

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  canonical_name text not null,
  brand text,
  model text,
  gtin text,
  mpn text,
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists products_gtin_unique on products(gtin) where gtin is not null;

create table if not exists offers (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references products(id) on delete cascade,
  source text not null,
  external_id text not null,
  title text not null,
  url text not null,
  image_url text,
  seller text,
  country_code text,
  currency text not null,
  price numeric(14,2) not null,
  shipping numeric(14,2) default 0,
  condition text,
  availability text,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(source, external_id)
);

create index if not exists offers_product_idx on offers(product_id);
create index if not exists offers_last_seen_idx on offers(last_seen);

create table if not exists price_history (
  id bigserial primary key,
  offer_id uuid references offers(id) on delete cascade,
  price numeric(14,2) not null,
  shipping numeric(14,2) default 0,
  currency text not null,
  recorded_at timestamptz not null default now()
);

create table if not exists search_logs (
  id bigserial primary key,
  query text not null,
  searched_at timestamptz not null default now()
);
